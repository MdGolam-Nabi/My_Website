// ===== PDF LIST =====
// Notun PDF add korte ei list-e ekta line jog koro (comma shoho).
// Notun file shobar upore rakho, tahole shobar age dekhabe.
// Format:  { title: "PDF er naam", url: "share link", date: "2026-10-21" },
// "date" optional.

window.PDFS = [
  // { title: "Example Notes", url: "https://drive.google.com/file/d/FILE_ID/view", date: "2026-10-21" },
];
